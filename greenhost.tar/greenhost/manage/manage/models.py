from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser,User
from django.contrib.auth.models import AbstractUser

class Member(AbstractUser):
    ftppassword =  models.CharField('ftp用户名',max_length=200,default='')
    class Mete:
        verbose_name = '成员'
        verbose_name_plural = '成员管理'
 
