from django.apps import AppConfig


class SitemanageConfig(AppConfig):
    name = 'sitemanage'
