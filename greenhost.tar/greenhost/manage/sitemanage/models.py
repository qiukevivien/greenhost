from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser,User
from django.contrib.auth.models import AbstractUser

class Member(AbstractUser):
    ftppassword =  models.CharField('ftp密码',max_length=200,default='')
    module_name = models.CharField('module_name',max_length=200,default='')
    application_name = models.CharField('applacation_name',max_length=200,default='application')
    domain = models.CharField('domain',max_length=200,default='null')

    class Mete:
        verbose_name = '成员'
        verbose_name_plural = '成员管理'
 
