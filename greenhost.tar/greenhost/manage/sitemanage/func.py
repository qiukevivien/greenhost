import os,sys


def create_ftp_vuser_conf(username,template_file):
    try:
        f_temp = open(template_file)
        vuser_ftp_dir = '/etc/vsftpd/vusers/'
        f_user = open(vuser_ftp_dir + username,'w')
        f_user.write(f_temp.read().replace('vsftpd_vsuer',username))
        f_temp.close()
        f_user.close()
        return 0
    except ZeroDivisionError as err:
        #print ('Exception: ', err)
        return -1

def create_uwsgi_vuser_conf(member,template_file):
    try:
        f_temp = open(template_file)
        vuser_uwsgi_dir = '/etc/uwsgi/'
        f_user = open(vuser_uwsgi_dir + member['username']+'.ini','w')
        socket_port = 9000 + member['member_id']
        f_user.write(f_temp.read().replace('{{app_dir}}','/home/vhost/'+member['username']).replace('{{app_name}}',member['application_name']).replace('{{module_name}}',member['module_name']).replace('{{socket_port}}',str(socket_port)))
        f_temp.close()
        f_user.close()
        #os.popen('systemctl reload uwsgi.service')
        return 0
    except ZeroDivisionError as err:
        return -1
def create_nginx_vuser_conf(member,template_file):
    try:
        f_temp = open(template_file)
        vuser_nginx_dir = '/etc/nginx/conf.d/'
        f_user = open(vuser_nginx_dir + member['username'] +'.conf','w')
        socket_port = 9000 + member['member_id']
        f_user.write(f_temp.read().replace('{{username}}',member['username']).replace('{{domain}}',member['domain']).replace('{{socket_port}}',str(socket_port)))
        f_temp.close()
        f_user.close()
        os.popen('systemctl reload nginx.service')
        return 0
    except ZeroDivisionError as err:
        return -1

#if __name__ == '__main__':
#    create_ftp_vuser_conf('jack','/greenhost/manage/sitemanage/file_template/vsftpd_vsuer')
