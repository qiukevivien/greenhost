from django.contrib import admin
from .models import Member
from django.contrib.auth.admin import UserAdmin #使用django自己的UserAdmin来注册
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.utils.translation import gettext, gettext_lazy as _
import os, sys

from .func import create_ftp_vuser_conf,create_uwsgi_vuser_conf,create_nginx_vuser_conf
# Register your models here.


class MyUserChangeForm(UserChangeForm):  # 编辑用户表单重新定义，继承自UserChangeForm
    def __init__(self, *args, **kwargs):
        super(MyUserChangeForm, self).__init__(*args, **kwargs)
        self.fields['username'].disabled = True
class MemberAdmin(UserAdmin):
    #重写fieldsets在admin后台加入自己新增的字段
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        (_('Personal info'), {'fields': ('first_name', 'last_name', 'email')}),
        (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser',
                                       'groups', 'user_permissions')}),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
        (_('application settings'), {'fields': ('domain','ftppassword','module_name','application_name')}),
    )
    #readonly_fields = ('username',)
    def __init__(self, *args, **kwargs):
        super(MemberAdmin, self).__init__(*args, **kwargs)
        #self.list_display = ('username', 'name', 'email', 'is_active', 'is_staff', 'is_superuser')
        #self.search_fields = ('username', 'email', 'name')
        self.form = MyUserChangeForm  #  编辑用户表单，使用自定义的表单
    def save_model(self, request, obj, form, change):
        # 自定义操作
        print(change)
#       if request.path == '/admin/sitemanage/member/add/':
        if change == False:
            username = form.cleaned_data['username']
            website_path = "/home/vhost/"+username+"/website"
            os.makedirs(website_path)
            log_path = "/home/vhost/"+username+"/log"
            os.makedirs(log_path)
            res = os.popen('id -gn vuser')
            vuser_gname = res.read()
            os.popen("chown -R vuser:vuser /home/vhost/"+username)
            vsftp_vuser_temp = '/greenhost/manage/sitemanage/file_template/vsftpd_vsuer'
            create_ftp_vuser_conf(username,vsftp_vuser_temp)
            obj.ftppassword = request.POST['password1']
           
        if change==True:
            uwsgi_vuser_temp = '/greenhost/manage/sitemanage/file_template/uwsgi_template.ini'
            nginx_vuser_temp = '/greenhost/manage/sitemanage/file_template/nginx_vhost_template.conf'
            changeuser = Member.objects.get(username = form.cleaned_data['username'])
            member = {}
            member['username']=form.cleaned_data['username']
            member['application_name'] = form.cleaned_data['application_name']
            member['module_name'] = form.cleaned_data['module_name']
            member['member_id'] = changeuser.id
            member['domain'] = form.cleaned_data['domain']
            create_uwsgi_vuser_conf(member,uwsgi_vuser_temp)
            create_nginx_vuser_conf(member,nginx_vuser_temp)
        obj.save()

admin.site.register(Member,MemberAdmin)
